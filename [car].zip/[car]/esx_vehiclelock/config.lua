Config = {}

Config.DrawDistance = 100
Config.Size         = {x = 1.5, y = 1.5, z = 1.5}
Config.Color        = {r = 0, g = 128, b = 255}
Config.Type         = 27
Config.coef         = 0.10
Config.Locale = 'fr'

--[[
Config.Zones = {
		place = {
				Pos = {x = -29.38, y = -1103.39, z = 25.47},
				Size  = {x = 1.5, y = 1.5, z = 1.0},
				Color = {r = 204, g = 204, b = 0},
				Type  = 27
			}
}
--]]
---------------------------------
--- Copyright by ikNox#6088 ---
---------------------------------