resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

description 'EssentialMode 5 CarWash by TheSpartaPT.'

client_script 'es_carwash_client.lua'
server_script 'es_carwash_server.lua'
