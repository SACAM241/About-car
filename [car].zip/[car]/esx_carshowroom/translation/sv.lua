Locales['sv'] = {
  -- Allting
  ['press_e'] = 'Tryck ~INPUT_CONTEXT~ för att kolla på bilar',
  ['costs'] = ' Kostar: ',
  ['currency'] = ' SEK',
  ['back'] = 'Tillbaka',
  ['contact_dealer'] = 'Ta kontakt med bilförsäljaren för att köpa denna bil, den kostar ju somsagt: ',
  ['press_e_to_enter'] = 'Tryck ~INPUT_CONTEXT~ för att åka ner med hissen',
  ['press_e_to_exit'] = 'Tryck ~INPUT_CONTEXT~ för att åka upp med hissen',
}