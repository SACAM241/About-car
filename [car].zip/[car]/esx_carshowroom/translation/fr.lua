Locales['fr'] = {
  -- Everything
  ['press_e'] = 'Appuyez sur ~INPUT_CONTEXT~ pour ouvrir le menu',
  ['costs'] = ' Prix: ',
  ['currency'] = ' $',
  ['back'] = 'Revenir en arrière',
  ['avert'] = 'N\'utilisez pas la touche ECHAP',
  ['contact_dealer'] = 'Contactez le revendeur, cela coûte: ',
  ['press_e_to_enter'] = 'Appuyez sur ~INPUT_CONTEXT~ pour entrer',
  ['press_e_to_exit'] = 'Appuyez sur ~INPUT_CONTEXT~ pour sortir',
}