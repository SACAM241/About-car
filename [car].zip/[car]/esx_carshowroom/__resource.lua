resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

client_scripts {
  '@es_extended/locale.lua',
  'translation/sv.lua',
  'translation/en.lua',
  'translation/fr.lua',
  'config.lua',
  'client/main.lua',
}

