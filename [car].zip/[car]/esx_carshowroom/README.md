# esx_carshowroom

[REQUIREMENTS]
  
* ESX Support
  * esx_vehicleshop => https://github.com/ESX-Org/esx_vehicleshop

[INSTALLATION]

1) CD in your resources/[esx] folder

2) Add this in your server.cfg :
``start esx_carshowroom``

lua