This script is simple as fuck, only thing it does is allow you to sell your car or simply give it away to the nearest player.

Requirements:

https://github.com/ESX-Org/esx_vehicleshop

How to make it work:

· Move the esx_givecarkeys folder to your resources folder

· Add start esx_givecarkeys to server.cfg

· Restart server

· Hop into a owned car and do /givecarkeys and the nearest player will receive the car.

No big deal, if you want to roleplay a car sale, make sure to roleplay he pays you too.


If you want to have the option to be able to use a menu to hand the keys

use this event from your menu

esx_givecarkeys:frommenu
