resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'

data_file 'VEHICLE_METADATA_FILE' 'handling.meta'

files {
	'handling.meta'
}

client_script 'RealisticTraffic_cl.lua'